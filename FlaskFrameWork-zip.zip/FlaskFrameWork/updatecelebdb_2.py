import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#SQL SELECT statement
sql = '''update celebs set bio = "A disney princess who meets seven dwarves and faces an evil queen!" where celebID = 3'''
cursor.execute(sql)
#commit the changes
conn.commit()
conn.close()
