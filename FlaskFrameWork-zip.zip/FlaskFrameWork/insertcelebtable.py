import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#data supplied as tuple of tuples.? - placeholders for data
sql = "insert into celebs values (?,?,?,?,?,?,?)"
data = ((1, "Angelina", "Jolie", 40, "anie@hollywood.us", "http://www.nphinity.com/pics/aj.jpg", "Known for being in the films Salt and Maleficent!"),
        (2, "Brad", "Pitt", 51, "brad@hollywood.us", "http://www.nphinity.com/pics/bp.jpg", "Known for being in the films Fight Club, Troy, and Ocean's Eleven!"),
        (3, "Snow", "White", 21, "sw@disney.org", "http://www.nphinity.com/pics/sw.jpg", "A disney princess that meets seven dwarfs and faces an evil queen!"),
        (4, "Darth", "Vader", 29, "dv@darkside.me", "http://www.nphinity.com/pics/dv.jpg", "Most formidable sith in the universe!"),
        (5, "Taylor", "Swift", 25, "ts@1989.us", "http://www.nphinity.com/pics/ts.jpg", "American singer known for You Belong with Me and Shake It Off!"),
        (6, "Beyonce", "Knowles", 34, "beyonce@jayz.me", "http://www.nphinity.com/pics/bk.jpg", "American singer known for Crazy in Love and B'day!"),
        (7, "Selena", "Gomez", 23, "selena@hollywood.us", "http://www.nphinity.com/pics/sg.jpg", "American singer known for Stars Dance and Revival!"),
        (8, "Stephen", "Curry", 27, "stephi@golden.bb", "http://www.nphinity.com/pics/sc.jpg", "Pro basketball player known for his shooting ability!"))
cursor.executemany(sql, data)
#commit the changes
conn.commit()
conn.close()
