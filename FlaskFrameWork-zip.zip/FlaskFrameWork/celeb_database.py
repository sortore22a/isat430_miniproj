#Import the built-in sqlite3 module
import sqlite3
#Create and connect to a database
conn = sqlite3.connect("celebrities.db")
#get a cusor to work with the database
#a databasae cursor is an object used to pinpoint records in a database
cursor = conn.cursor()
#close the connection to the database
conn.close()

