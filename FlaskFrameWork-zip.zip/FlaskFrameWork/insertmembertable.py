import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#data supplied as tuple of tuples.? - placeholders for data
sql = "insert into members values (?,?,?,?,?,?)"
data = ((1, "Aaron", "Sortore", 22, "sortorak@dukes.jmu.edu", "Roanoke!"), (2, "Chase", "Gibson", 21, "gibsoncc@dukes.jmu.edu", "ISAT Major"))
cursor.executemany(sql, data)
#commit the changes
conn.commit()
conn.close()
