import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#create a table called "login" with 3 fields - loginID, user, passwords
sql = "create table login (loginID integer PRIMARY KEY, user text, passwords text)"
cursor.execute(sql)
#commit the changes to the database
conn.commit()
conn.close()
