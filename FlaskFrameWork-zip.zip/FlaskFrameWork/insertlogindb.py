import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#data supplied as tuple of tuples.? - placeholders for data
sql = "insert into login values (?,?,?)"
data = ((1, "aaron", "sortore"), (2, "chase", "gibson"))
cursor.executemany(sql, data)
#commit the changes
conn.commit()
conn.close()
