import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#create a table called "members" with 6 fields - memberID, firstname, lastname, age, email, bio
sql = "create table members (memberID integer PRIMARY KEY, firstname text, lastname text, age integer, email text, bio text)"
cursor.execute(sql)
#commit the changes to the database
conn.commit()
conn.close()
