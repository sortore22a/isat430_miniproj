import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()
#create a table called "celebs" with 7 fields - celebID, firstname, lastname, age, email, photo, bio
sql = "create table celebs (celebID integer PRIMARY KEY, firstname text, lastname text, age integer, email text, photo text, bio text)"
cursor.execute(sql)
#commit the changes to the database
conn.commit()
conn.close()
